const config = require('flarum-webpack-config');

module.exports = config();
