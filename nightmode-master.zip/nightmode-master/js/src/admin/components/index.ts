import NightmodeSettingsPage from './NightmodeSettingsPage';

export const components = {
  NightmodeSettingsPage,
};
