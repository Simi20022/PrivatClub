declare const _default: import("flarum/common/extenders/Admin").default[];
export default _default;
