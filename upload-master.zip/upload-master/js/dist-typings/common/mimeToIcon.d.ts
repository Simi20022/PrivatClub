export default function mimeToIcon(fileType: string): string;
