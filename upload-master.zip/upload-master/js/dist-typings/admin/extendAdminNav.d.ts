export default function extendAdminNav(): void;
