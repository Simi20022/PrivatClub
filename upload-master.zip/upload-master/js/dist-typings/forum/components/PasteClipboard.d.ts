export default class PasteClipboard {
    constructor(upload: any, element: any);
    upload: any;
    paste(e: any): void;
}
