export default function addUserPageButton(): void;
