import UploadPage from './UploadPage';
import { commonComponents } from '../../common/components';

export const components = {
  ...commonComponents,
  UploadPage,
};
