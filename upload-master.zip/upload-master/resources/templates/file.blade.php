<div class="ButtonGroup" data-fof-upload-download-uuid="{@uuid}">
    <div class="Button hasIcon Button--icon Button--primary"><i class="fas fa-download"></i></div>
    <div class="Button">
        {SIMPLETEXT1}
    </div>
    <div class="Button">
        <xsl:value-of select="@size"/>
    </div>
</div>
