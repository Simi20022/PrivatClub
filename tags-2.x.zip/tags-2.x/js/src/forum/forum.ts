import '../common/common';

import './utils/getSelectableTags';

import './components/TagHero';
import './components/TagsPage';
import './components/DiscussionTaggedPost';
import './components/TagLinkButton';

import './addTagFilter';
import './addTagControl';
import './addTagList';
import './addTagLabels';
import './addTagComposer';
