import '../common/common';

import './components/TagsPage';
import './components/EditTagModal';

import './addTagsHomePageOption';
import './addTagChangePermission';
import './addTagsPermissionScope';
