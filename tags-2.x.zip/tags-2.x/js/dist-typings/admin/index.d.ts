export { default as extend } from './extend';
import './admin';
