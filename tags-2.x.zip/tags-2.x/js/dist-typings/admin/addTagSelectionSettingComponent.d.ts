export default function (): void;
