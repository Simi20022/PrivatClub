export default function addTagFilter(): void;
