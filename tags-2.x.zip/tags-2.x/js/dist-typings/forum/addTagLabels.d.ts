export default function addTagLabels(): void;
