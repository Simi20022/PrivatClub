declare const _default: (import("flarum/common/extenders/Store").default | import("flarum/common/extenders/Search").default | import("flarum/common/extenders/Routes").default | import("flarum/common/extenders/PostTypes").default | import("flarum/common/extenders/Model").default)[];
export default _default;
