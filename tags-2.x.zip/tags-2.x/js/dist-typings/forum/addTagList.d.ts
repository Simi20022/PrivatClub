export default function addTagList(): void;
