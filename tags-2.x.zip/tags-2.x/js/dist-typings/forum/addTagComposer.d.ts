export default function addTagComposer(): void;
