export default function addTagControl(): void;
