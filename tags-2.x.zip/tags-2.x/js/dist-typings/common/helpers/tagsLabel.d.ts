export default function tagsLabel(tags: any, attrs?: {}): JSX.Element;
