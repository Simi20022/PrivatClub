export default function tagIcon(tag: any, attrs?: {}, settings?: {}): JSX.Element;
