export default function tagLabel(tag: any, attrs?: {}): import("mithril").Vnode<import("flarum/common/Component").ComponentAttrs, any>;
