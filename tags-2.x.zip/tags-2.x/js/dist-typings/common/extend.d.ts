declare const _default: (import("flarum/common/extenders/Store").default | import("flarum/common/extenders/Search").default)[];
export default _default;
