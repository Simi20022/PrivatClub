import ByobuSettingsPage from './ByobuSettingsPage';

export const components = {
  ByobuSettingsPage,
};
