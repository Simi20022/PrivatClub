import Extend from 'flarum/common/extenders';

export default [];
