import DiscussionListState from 'flarum/forum/states/DiscussionListState';

export default class PrivateDiscussionListState extends DiscussionListState {}
