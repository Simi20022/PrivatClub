import MadePublic from './MadePublic';
import RecipientLeft from './RecipientLeft';
import RecipientsModified from './RecipientsModified';

export const events = [MadePublic, RecipientLeft, RecipientsModified];
