import PrivateDiscussionsPage from './PrivateDiscussionsPage';

export default () => {
  PrivateDiscussionsPage();
};
