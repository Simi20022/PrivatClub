import DiscussionList from 'flarum/forum/components/DiscussionList';

export default class PrivateDiscussionList extends DiscussionList {}
