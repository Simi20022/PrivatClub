import canStartPrivateDiscussion from './canStartPrivateDiscussion';

export const helpers = [canStartPrivateDiscussion];
