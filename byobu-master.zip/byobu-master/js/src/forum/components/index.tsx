import PrivateComposerPage from './PrivateComposerPage';
import PrivateHero from './PrivateHero';

export const components = {
  PrivateHero,
  PrivateComposerPage,
};
